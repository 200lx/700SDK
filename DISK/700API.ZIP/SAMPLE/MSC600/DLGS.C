#include "cmds.h"
#include "cap2.h"
#include "interfac.h"

#include "dialogs\sendmsg.rc"
#include "dialogs\fetchmsg.rc"

